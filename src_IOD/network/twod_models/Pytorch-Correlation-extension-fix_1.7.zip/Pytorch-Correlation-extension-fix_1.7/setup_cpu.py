import setup

setup.CPU_ONLY = True
setup.launch_setup()
